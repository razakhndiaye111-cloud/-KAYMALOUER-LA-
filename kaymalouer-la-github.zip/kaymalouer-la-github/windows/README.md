# KAYMALOUER LA — Logiciel Windows (Electron)

Ce dossier enveloppe l'application (`www/index.html`) dans un logiciel Windows.
Je n'ai pas pu produire le fichier .exe ici (il faut Windows ou GitHub pour le compiler).

## Option A — sur ton PC Windows
1. Installe Node.js 18+ : https://nodejs.org
2. Dans ce dossier : `npm install`
3. Pour tester : `npm start`
4. Pour créer le logiciel : `npm run dist`
   Résultat dans `dist/` : un installateur `KAYMALOUER LA Setup 1.0.0.exe` et une version portable `.exe` (sans installation).

## Option B — sans rien installer, avec GitHub
1. Crée un dépôt GitHub (privé ou public) et envoie-y tout ce dossier.
2. Onglet **Actions > Build Windows > Run workflow**.
3. Quand c'est vert, ouvre l'exécution et télécharge **KAYMALOUER-LA-Windows** (les .exe sont dedans).

## Icône
Ajoute un fichier `build/icon.ico` (256×256) avant `npm run dist` pour remplacer l'icône par défaut.

## À savoir
- Windows affichera un avertissement SmartScreen tant que le logiciel n'est pas signé avec un certificat de signature de code (payant). « Informations complémentaires > Exécuter quand même » permet de l'ouvrir.
- Les annonces et comptes restent enregistrés sur chaque ordinateur tant que le logiciel n'est pas branché au serveur (dossier kaymalouer-server).
- La saisie vocale « Parler à l'IA » ne fonctionne pas dans Electron ; l'écriture marche.
