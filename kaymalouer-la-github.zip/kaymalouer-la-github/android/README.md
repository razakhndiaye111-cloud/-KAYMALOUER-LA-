# KAYMALOUER LA — Projet Android (APK / AAB)

Ce dossier enveloppe l'application web (`www/index.html`) dans une application Android avec Capacitor.
Je n'ai pas pu compiler le fichier ici : il faut Android Studio et le SDK Android, que mon environnement n'a pas.

## À installer une seule fois
1. Node.js 18+ : https://nodejs.org
2. Android Studio (inclut le SDK et Java) : https://developer.android.com/studio

## Générer l'APK de test (à installer sur un téléphone)
```
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug        # Windows : gradlew.bat assembleDebug
```
Fichier obtenu : `android/app/build/outputs/apk/debug/app-debug.apk`
Envoie-le sur ton téléphone et ouvre-le (autorise l'installation depuis cette source).

## Générer l'AAB pour Google Play
1. Ouvre le projet : `npx cap open android`
2. Menu **Build > Generate Signed App Bundle / APK > Android App Bundle**.
3. **Create new…** pour créer ta clé (keystore). Sauvegarde le fichier `.jks` et ses mots de passe dans un endroit sûr : sans eux tu ne pourras plus mettre l'application à jour. Ne les publie jamais sur GitHub.
4. Choisis **release** puis Finish. Fichier obtenu : `android/app/release/app-release.aab`
5. Dans la Google Play Console (compte développeur, 25 USD une fois), crée l'application et envoie cet AAB.

## Icône et nom
- Mets une image carrée `assets/icon.png` (1024×1024) puis lance `npx @capacitor/assets generate --android`.
- Identifiant de l'application : `sn.kaymalouer.app` (à changer dans `capacitor.config.json` avant `npx cap add android` si tu veux un autre).

## À savoir avant Google Play
- Les données (annonces, comptes, favoris) restent sur chaque téléphone tant que l'application n'est pas branchée au serveur (dossier kaymalouer-server).
- La saisie vocale « Parler à l'IA » ne fonctionne pas dans une application Android de ce type ; l'écriture marche.
- Google Play demande une politique de confidentialité en ligne et les informations de sécurité des données.
