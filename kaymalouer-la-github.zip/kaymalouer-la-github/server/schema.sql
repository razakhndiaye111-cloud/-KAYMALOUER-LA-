CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text UNIQUE NOT NULL,
  email text UNIQUE,
  password_hash text NOT NULL,
  role text NOT NULL DEFAULT 'tenant' CHECK (role IN ('tenant','owner','agency','admin')),
  blocked boolean NOT NULL DEFAULT false,
  verified boolean NOT NULL DEFAULT false,
  failed_logins int NOT NULL DEFAULT 0,
  locked_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS categories (
  id serial PRIMARY KEY, slug text UNIQUE NOT NULL, label text NOT NULL
);
INSERT INTO categories (slug,label) VALUES
 ('appartement','Appartement'),('chambre','Chambre'),('maison','Maison'),
 ('magasin','Magasin'),('bureau','Bureau'),('local-commercial','Local commercial')
ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS locations (
  id serial PRIMARY KEY,
  city text NOT NULL, district text NOT NULL DEFAULT '', region text,
  lat double precision, lng double precision,
  UNIQUE (city, district)
);
INSERT INTO locations (city,district) VALUES
 ('Dakar','Yoff'),('Dakar','Almadies'),('Dakar','Ouakam'),('Dakar','Parcelles Assainies'),
 ('Dakar','Grand-Yoff'),('Dakar','Sacré-Cœur'),('Pikine',''),('Guédiawaye',''),
 ('Rufisque',''),('Thiès',''),('Touba','')
ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id int NOT NULL REFERENCES categories(id),
  location_id int NOT NULL REFERENCES locations(id),
  title text NOT NULL, description text NOT NULL DEFAULT '',
  price int NOT NULL CHECK (price > 0),
  bedrooms int NOT NULL DEFAULT 0, bathrooms int NOT NULL DEFAULT 0, surface int NOT NULL DEFAULT 0,
  address text NOT NULL DEFAULT '',
  amenities text[] NOT NULL DEFAULT '{}',
  whatsapp text,
  available boolean NOT NULL DEFAULT true,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','rejected','blocked')),
  reject_reason text,
  views int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_prop_status ON properties(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_prop_search ON properties(category_id, location_id, price);

CREATE TABLE IF NOT EXISTS property_images (
  id serial PRIMARY KEY,
  property_id uuid NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  url text NOT NULL, position int NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS favorites (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  property_id uuid NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, property_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id serial PRIMARY KEY,
  property_id uuid NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body text NOT NULL, read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reports (
  id serial PRIMARY KEY,
  property_id uuid NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  reporter_id uuid REFERENCES users(id) ON DELETE SET NULL,
  reason text NOT NULL,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS events (
  id bigserial PRIMARY KEY,
  type text NOT NULL, property_id uuid, user_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
