require("dotenv").config();
const { Pool } = require("pg"), bcrypt = require("bcryptjs");
const { DATABASE_URL, ADMIN_PHONE, ADMIN_PASSWORD, ADMIN_NAME } = process.env;
if (!DATABASE_URL || !ADMIN_PHONE || !ADMIN_PASSWORD || ADMIN_PASSWORD.length < 10) {
  console.error("Renseigne DATABASE_URL, ADMIN_PHONE et ADMIN_PASSWORD (10+ caractères) dans .env");
  process.exit(1);
}
const pool = new Pool({ connectionString: DATABASE_URL, ssl: process.env.DB_SSL === "false" ? false : { rejectUnauthorized: false } });
(async () => {
  const phone = ADMIN_PHONE.replace(/\D/g, "");
  const hash = await bcrypt.hash(ADMIN_PASSWORD, 12);
  await pool.query(
    `INSERT INTO users (name,phone,password_hash,role,verified) VALUES ($1,$2,$3,'admin',true)
     ON CONFLICT (phone) DO UPDATE SET role='admin', password_hash=EXCLUDED.password_hash`,
    [ADMIN_NAME || "Admin", phone, hash]);
  console.log("Administrateur prêt :", phone);
  await pool.end();
})().catch(e => { console.error(e.message); process.exit(1); });
