# KAYMALOUER LA — Serveur API (Node.js + Express + PostgreSQL)

## Démarrage local
1. `npm install`
2. Crée une base PostgreSQL, copie `.env.example` en `.env` et remplis `DATABASE_URL` et `JWT_SECRET` (`openssl rand -hex 32`).
3. `npm run db:init` (crée les tables) puis renseigne `ADMIN_PHONE` / `ADMIN_PASSWORD` dans `.env` et lance `npm run seed:admin`.
4. `npm run dev` → http://localhost:4000/api/health

## Déploiement (Render ou Railway + base Neon/Supabase)
- Variables d'environnement à créer sur l'hébergeur : `DATABASE_URL`, `JWT_SECRET`, `CORS_ORIGINS` (URL de ton site), `WHATSAPP_NUMBER`, `AI_API_KEY` (optionnel), `AI_MODEL`.
- Commande de build `npm install`, commande de démarrage `npm start`. HTTPS est fourni par l'hébergeur.
- Les photos sont enregistrées dans `uploads/` : sur ces hébergeurs le disque est effacé à chaque redéploiement. Ajoute un disque persistant ou un stockage objet (Supabase Storage, Cloudinary, S3) avant le lancement public.

## Routes
Publiques : `GET /api/properties` (q, category, city, district, min, max, bedrooms, sort, page), `GET /api/properties/:id`, `GET /api/categories`, `GET /api/config`, `POST /api/ai`, `POST /api/track`.
Compte : `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/me`.
Connecté : favoris (`/api/favorites`), messages (`/api/messages`), signalement (`POST /api/reports`).
Propriétaire/agence : `POST/PUT/DELETE /api/properties`, `POST /api/properties/:id/images`, `GET /api/my/properties`.
Admin : `/api/admin/stats`, `/properties`, `/properties/:id/status`, `/users`, `/users/:id/block`, `/reports`, `/categories`.

## Sécurité en place
Mots de passe bcrypt, JWT 7 jours, blocage de compte après 5 échecs, limitation de débit, helmet, CORS restreint, requêtes SQL paramétrées, validation zod, images contrôlées (type réel, 3 Mo, 8 max), annonces validées par l'admin avant publication, clé IA uniquement côté serveur.

## Pas encore fait
Vérification OTP par SMS/WhatsApp, e-mails, stockage objet pour les photos, tests automatisés.
