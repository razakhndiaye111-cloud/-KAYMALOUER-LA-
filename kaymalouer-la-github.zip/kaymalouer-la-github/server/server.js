require("dotenv").config();
const express = require("express"), helmet = require("helmet"), cors = require("cors"),
  rateLimit = require("express-rate-limit"), multer = require("multer"), { Pool } = require("pg"),
  bcrypt = require("bcryptjs"), jwt = require("jsonwebtoken"), { z } = require("zod"),
  crypto = require("crypto"), fs = require("fs"), path = require("path");

const { JWT_SECRET, DATABASE_URL, AI_API_KEY } = process.env;
if (!JWT_SECRET || JWT_SECRET.length < 32 || !DATABASE_URL) {
  console.error("JWT_SECRET (32+ caractères) et DATABASE_URL sont obligatoires (voir .env.example)");
  process.exit(1);
}
const WA = (process.env.WHATSAPP_NUMBER || "221776785161").replace(/\D/g, "");
const pool = new Pool({ connectionString: DATABASE_URL, ssl: process.env.DB_SSL === "false" ? false : { rejectUnauthorized: false } });
const q = (t, p) => pool.query(t, p);
const UP = path.join(__dirname, "uploads"); fs.mkdirSync(UP, { recursive: true });

const app = express();
app.set("trust proxy", 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors({ origin: (process.env.CORS_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean) }));
app.use(express.json({ limit: "100kb" }));
const lim = (ms, max) => rateLimit({ windowMs: ms, max, standardHeaders: true, legacyHeaders: false, message: { error: "Trop de requêtes, réessayez plus tard." } });
app.use("/api", lim(15 * 60e3, 600));
const authLim = lim(15 * 60e3, 15), aiLim = lim(60e3, 15), postLim = lim(3600e3, 20), trackLim = lim(60e3, 30), msgLim = lim(60e3, 10);
app.use("/uploads", express.static(UP, { maxAge: "7d", index: false }));

const wrap = f => (req, res, next) => f(req, res, next).catch(next);
const fail = (res, c, m) => res.status(c).json({ error: m });
const uid = z.string().uuid();

/* ---------- Auth & validation ---------- */
const phoneZ = z.string().transform(s => s.replace(/\D/g, "")).refine(s => /^(221)?(7[05678]|3[03])\d{7}$/.test(s), "Numéro sénégalais invalide").transform(s => (s.length === 9 ? "221" + s : s));
const sign = u => jwt.sign({ sub: u.id }, JWT_SECRET, { expiresIn: "7d" });
const pub = u => ({ id: u.id, name: u.name, phone: u.phone, email: u.email, role: u.role });
const auth = (...roles) => wrap(async (req, res, next) => {
  const h = req.headers.authorization || "";
  if (!h.startsWith("Bearer ")) return fail(res, 401, "Connexion requise");
  let d; try { d = jwt.verify(h.slice(7), JWT_SECRET); } catch { return fail(res, 401, "Session expirée"); }
  const { rows: [u] } = await q("SELECT id,name,phone,email,role,blocked FROM users WHERE id=$1", [d.sub]);
  if (!u || u.blocked) return fail(res, 403, "Compte indisponible");
  if (roles.length && !roles.includes(u.role)) return fail(res, 403, "Accès refusé");
  req.user = u; next();
});

app.post("/api/auth/register", authLim, wrap(async (req, res) => {
  const d = z.object({
    name: z.string().trim().min(2).max(80), phone: phoneZ,
    email: z.string().trim().email().max(120).optional().or(z.literal("").transform(() => undefined)),
    password: z.string().min(8).max(72), role: z.enum(["tenant", "owner", "agency"]).default("tenant")
  }).parse(req.body);
  try {
    const { rows: [u] } = await q("INSERT INTO users (name,phone,email,password_hash,role) VALUES ($1,$2,$3,$4,$5) RETURNING *",
      [d.name, d.phone, d.email || null, await bcrypt.hash(d.password, 12), d.role]);
    res.status(201).json({ token: sign(u), user: pub(u) });
  } catch (e) { if (e.code === "23505") return fail(res, 409, "Téléphone ou email déjà utilisé"); throw e; }
}));

app.post("/api/auth/login", authLim, wrap(async (req, res) => {
  const d = z.object({ phone: phoneZ, password: z.string().min(1).max(72) }).parse(req.body);
  const { rows: [u] } = await q("SELECT * FROM users WHERE phone=$1", [d.phone]);
  const bad = () => fail(res, 401, "Téléphone ou mot de passe incorrect");
  if (!u) return bad();
  if (u.blocked) return fail(res, 403, "Compte bloqué");
  if (u.locked_until && u.locked_until > new Date()) return fail(res, 429, "Trop d'essais, réessayez dans quelques minutes");
  if (!(await bcrypt.compare(d.password, u.password_hash))) {
    await q("UPDATE users SET failed_logins=failed_logins+1, locked_until=CASE WHEN failed_logins+1>=5 THEN now()+interval '15 minutes' ELSE locked_until END WHERE id=$1", [u.id]);
    return bad();
  }
  await q("UPDATE users SET failed_logins=0, locked_until=NULL WHERE id=$1", [u.id]);
  res.json({ token: sign(u), user: pub(u) });
}));
app.get("/api/me", auth(), (req, res) => res.json({ user: pub(req.user) }));

/* ---------- Annonces ---------- */
const BASE = `SELECT p.*, c.slug AS category, l.city, l.district, u.name AS owner_name,
  COALESCE((SELECT json_agg(url ORDER BY position) FROM property_images i WHERE i.property_id=p.id),'[]') AS images
  FROM properties p JOIN categories c ON c.id=p.category_id JOIN locations l ON l.id=p.location_id JOIN users u ON u.id=p.owner_id`;
const dec = p => ({ ...p, wa_link: `https://wa.me/${p.whatsapp}?text=` + encodeURIComponent(`Bonjour, je suis intéressé(e) par votre ${p.category} situé à ${p.district || p.city}. Est-il toujours disponible ?`) });
const lk = s => "%" + s.replace(/[\\%_]/g, "\\$&") + "%";

async function searchProps(F, limit = 20) {
  const w = ["p.status='active'", "p.available"], v = [];
  const add = (sql, val) => { v.push(val); w.push(sql.replace(/\?/g, "$" + v.length)); };
  if (F.category) add("c.slug=?", F.category);
  if (F.city) add("l.city ILIKE ?", F.city);
  if (F.district) add("l.district ILIKE ?", lk(F.district));
  if (F.place) add("(l.city ILIKE ? OR l.district ILIKE ?)", lk(F.place));
  if (F.min != null) add("p.price>=?", F.min);
  if (F.max != null) add("p.price<=?", F.max);
  if (F.bedrooms) add("p.bedrooms>=?", F.bedrooms);
  if (F.q) add("(p.title ILIKE ? OR p.description ILIKE ?)", lk(F.q));
  const ord = { recent: "p.created_at DESC", price_asc: "p.price ASC", price_desc: "p.price DESC" }[F.sort || "recent"];
  const off = ((F.page || 1) - 1) * limit;
  const { rows } = await q(`${BASE} WHERE ${w.join(" AND ")} ORDER BY ${ord} LIMIT ${limit} OFFSET ${off}`, v);
  return rows.map(dec);
}

app.get("/api/properties", wrap(async (req, res) => {
  const F = z.object({
    q: z.string().max(80).optional(), category: z.string().max(40).optional(), city: z.string().max(60).optional(),
    district: z.string().max(60).optional(), min: z.coerce.number().int().min(0).optional(), max: z.coerce.number().int().min(0).optional(),
    bedrooms: z.coerce.number().int().min(0).max(30).optional(), page: z.coerce.number().int().min(1).max(500).default(1),
    sort: z.enum(["recent", "price_asc", "price_desc"]).default("recent")
  }).parse(req.query);
  q("INSERT INTO events (type) VALUES ('search')").catch(() => {});
  res.json({ items: await searchProps(F), page: F.page });
}));

app.get("/api/properties/:id", wrap(async (req, res) => {
  const id = uid.parse(req.params.id);
  const { rows: [p] } = await q(`${BASE} WHERE p.id=$1 AND p.status='active'`, [id]);
  if (!p) return fail(res, 404, "Annonce introuvable");
  q("UPDATE properties SET views=views+1 WHERE id=$1", [id]).catch(() => {});
  res.json(dec(p));
}));

const PropIn = z.object({
  category: z.string().max(40), title: z.string().trim().min(5).max(120), description: z.string().trim().max(3000).default(""),
  price: z.coerce.number().int().min(1000).max(1e9), city: z.string().trim().min(2).max(60), district: z.string().trim().max(60).default(""),
  address: z.string().trim().max(200).default(""), bedrooms: z.coerce.number().int().min(0).max(30).default(0),
  bathrooms: z.coerce.number().int().min(0).max(30).default(0), surface: z.coerce.number().int().min(0).max(100000).default(0),
  amenities: z.preprocess(v => (typeof v === "string" ? v.split(",").map(s => s.trim()).filter(Boolean) : v), z.array(z.string().max(40)).max(20).default([])),
  whatsapp: phoneZ.optional(), available: z.coerce.boolean().optional()
});
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 3 * 1024 * 1024, files: 8 } });
const sniff = b => b.length > 12 && (b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF ? "jpg"
  : b.slice(0, 4).equals(Buffer.from([0x89, 0x50, 0x4E, 0x47])) ? "png"
  : b.slice(0, 4).toString() === "RIFF" && b.slice(8, 12).toString() === "WEBP" ? "webp" : null);
function saveImages(files = []) {
  for (const f of files) if (!sniff(f.buffer)) throw Object.assign(new Error("Image invalide (JPG, PNG ou WebP uniquement)"), { status: 400 });
  return files.map(f => { const n = crypto.randomUUID() + "." + sniff(f.buffer); fs.writeFileSync(path.join(UP, n), f.buffer); return "/uploads/" + n; });
}
async function locId(city, district) {
  const { rows: [l] } = await q("INSERT INTO locations (city,district) VALUES ($1,$2) ON CONFLICT (city,district) DO UPDATE SET city=EXCLUDED.city RETURNING id", [city, district || ""]);
  return l.id;
}
async function addImages(id, urls) {
  const { rows: [m] } = await q("SELECT COALESCE(max(position),-1)+1 AS n FROM property_images WHERE property_id=$1", [id]);
  for (let i = 0; i < urls.length; i++) await q("INSERT INTO property_images (property_id,url,position) VALUES ($1,$2,$3)", [id, urls[i], m.n + i]);
}

app.post("/api/properties", postLim, auth("owner", "agency", "admin"), upload.array("images", 8), wrap(async (req, res) => {
  const d = PropIn.parse(req.body);
  const { rows: [n] } = await q("SELECT count(*)::int n FROM properties WHERE owner_id=$1 AND status='pending'", [req.user.id]);
  if (n.n >= 10) return fail(res, 429, "Trop d'annonces en attente de validation");
  const { rows: [c] } = await q("SELECT id FROM categories WHERE slug=$1", [d.category]);
  if (!c) return fail(res, 400, "Catégorie inconnue");
  const urls = saveImages(req.files);
  const { rows: [p] } = await q(`INSERT INTO properties (owner_id,category_id,location_id,title,description,price,bedrooms,bathrooms,surface,address,amenities,whatsapp)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
    [req.user.id, c.id, await locId(d.city, d.district), d.title, d.description, d.price, d.bedrooms, d.bathrooms, d.surface, d.address, d.amenities, d.whatsapp || req.user.phone]);
  await addImages(p.id, urls);
  res.status(201).json({ id: p.id, status: "pending", message: "Annonce envoyée, en attente de validation" });
}));

async function ownProp(req, res) {
  const id = uid.parse(req.params.id);
  const { rows: [o] } = await q(`SELECT p.*, c.slug AS category, l.city, l.district FROM properties p JOIN categories c ON c.id=p.category_id JOIN locations l ON l.id=p.location_id WHERE p.id=$1`, [id]);
  if (!o) { fail(res, 404, "Annonce introuvable"); return null; }
  if (o.owner_id !== req.user.id && req.user.role !== "admin") { fail(res, 403, "Interdit"); return null; }
  return o;
}
app.put("/api/properties/:id", auth(), wrap(async (req, res) => {
  const o = await ownProp(req, res); if (!o) return;
  const m = { ...o, ...PropIn.partial().parse(req.body) };
  const { rows: [c] } = await q("SELECT id FROM categories WHERE slug=$1", [m.category]);
  if (!c) return fail(res, 400, "Catégorie inconnue");
  await q(`UPDATE properties SET category_id=$1,location_id=$2,title=$3,description=$4,price=$5,bedrooms=$6,bathrooms=$7,surface=$8,address=$9,amenities=$10,whatsapp=$11,available=$12,
    status=$13,updated_at=now() WHERE id=$14`,
    [c.id, await locId(m.city, m.district), m.title, m.description, m.price, m.bedrooms, m.bathrooms, m.surface, m.address, m.amenities, m.whatsapp, m.available ?? true,
      req.user.role === "admin" ? o.status : "pending", o.id]);
  res.json({ ok: true });
}));
app.post("/api/properties/:id/images", postLim, auth(), upload.array("images", 8), wrap(async (req, res) => {
  const o = await ownProp(req, res); if (!o) return;
  await addImages(o.id, saveImages(req.files)); res.json({ ok: true });
}));
app.delete("/api/properties/:id", auth(), wrap(async (req, res) => {
  const o = await ownProp(req, res); if (!o) return;
  const { rows } = await q("SELECT url FROM property_images WHERE property_id=$1", [o.id]);
  await q("DELETE FROM properties WHERE id=$1", [o.id]);
  rows.forEach(r => fs.unlink(path.join(UP, path.basename(r.url)), () => {}));
  res.json({ ok: true });
}));
app.get("/api/my/properties", auth(), wrap(async (req, res) => {
  const { rows } = await q(`${BASE} WHERE p.owner_id=$1 ORDER BY p.created_at DESC`, [req.user.id]);
  res.json({ items: rows.map(dec) });
}));

/* ---------- Favoris, messages, signalements, suivi ---------- */
app.get("/api/favorites", auth(), wrap(async (req, res) => {
  const { rows } = await q(`${BASE} JOIN favorites f ON f.property_id=p.id WHERE f.user_id=$1 AND p.status='active' ORDER BY f.created_at DESC`, [req.user.id]);
  res.json({ items: rows.map(dec) });
}));
app.post("/api/favorites/:id", auth(), wrap(async (req, res) => {
  await q("INSERT INTO favorites (user_id,property_id) SELECT $1,id FROM properties WHERE id=$2 AND status='active' ON CONFLICT DO NOTHING", [req.user.id, uid.parse(req.params.id)]);
  res.status(201).json({ ok: true });
}));
app.delete("/api/favorites/:id", auth(), wrap(async (req, res) => {
  await q("DELETE FROM favorites WHERE user_id=$1 AND property_id=$2", [req.user.id, uid.parse(req.params.id)]); res.json({ ok: true });
}));

app.post("/api/messages", msgLim, auth(), wrap(async (req, res) => {
  const d = z.object({ property_id: uid, body: z.string().trim().min(1).max(1000) }).parse(req.body);
  const { rows: [p] } = await q("SELECT owner_id FROM properties WHERE id=$1 AND status='active'", [d.property_id]);
  if (!p) return fail(res, 404, "Annonce introuvable");
  if (p.owner_id === req.user.id) return fail(res, 400, "Vous ne pouvez pas vous écrire à vous-même");
  await q("INSERT INTO messages (property_id,sender_id,recipient_id,body) VALUES ($1,$2,$3,$4)", [d.property_id, req.user.id, p.owner_id, d.body]);
  res.status(201).json({ ok: true });
}));
app.get("/api/messages", auth(), wrap(async (req, res) => {
  const { rows } = await q(`SELECT m.id,m.body,m.read,m.created_at,m.property_id,pr.title,s.name AS sender_name,(m.sender_id=$1) AS mine
    FROM messages m JOIN properties pr ON pr.id=m.property_id JOIN users s ON s.id=m.sender_id
    WHERE m.sender_id=$1 OR m.recipient_id=$1 ORDER BY m.created_at DESC LIMIT 100`, [req.user.id]);
  res.json({ items: rows });
}));

app.post("/api/reports", msgLim, auth(), wrap(async (req, res) => {
  const d = z.object({ property_id: uid, reason: z.string().trim().min(3).max(500) }).parse(req.body);
  await q("INSERT INTO reports (property_id,reporter_id,reason) VALUES ($1,$2,$3)", [d.property_id, req.user.id, d.reason]);
  res.status(201).json({ ok: true });
}));
app.post("/api/track", trackLim, wrap(async (req, res) => {
  const d = z.object({ type: z.enum(["whatsapp_click"]), property_id: uid.optional() }).parse(req.body);
  await q("INSERT INTO events (type,property_id) VALUES ($1,$2)", [d.type, d.property_id || null]); res.json({ ok: true });
}));
app.get("/api/categories", wrap(async (_r, res) => res.json({ items: (await q("SELECT slug,label FROM categories ORDER BY id")).rows })));
app.get("/api/config", (_r, res) => res.json({ name: "KAYMALOUER LA", slogan: "Sa kër, sa choix !", whatsapp: "+" + WA, whatsapp_link: `https://wa.me/${WA}?text=` + encodeURIComponent("Bonjour KAYMALOUER LA, je cherche un bien à louer. Pouvez-vous m’aider ?") }));
app.get("/api/health", (_r, res) => res.json({ ok: true }));

/* ---------- KAYMALOUER AI (français + wolof) ---------- */
const CITIES = ["Yoff", "Almadies", "Ouakam", "Parcelles Assainies", "Grand-Yoff", "Sacré-Cœur", "Pikine", "Guédiawaye", "Rufisque", "Thiès", "Touba", "Dakar", "Saint-Louis", "Mbour", "Ziguinchor", "Kaolack"];
const nrm = s => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
const WN = {}; Object.entries({ benn: 1, un: 1, ñaar: 2, ñaari: 2, deux: 2, ñett: 3, ñetti: 3, trois: 3, ñent: 4, ñenti: 4, quatre: 4, juróom: 5, cinq: 5 }).forEach(([k, v]) => (WN[nrm(k)] = v));
function ruleParse(t) {
  const n = nrm(t), f = {};
  const T = { appartement: "appartement", chambre: "chambre", maison: "maison", magasin: "magasin", boutique: "magasin", bureau: "bureau", local: "local-commercial" };
  for (const k in T) if (n.includes(k)) { f.category = T[k]; break; }
  for (const c of CITIES) if (n.includes(nrm(c))) { f.place = c; break; }
  const pm = n.replace(/(\d)[\s.](?=\d{3}\b)/g, "$1").match(/\d{4,9}/), km = n.match(/(\d+)\s*(mille|k)\b/);
  if (pm) f.max = +pm[0]; else if (km) f.max = +km[1] * 1000;
  const w = n.split(/[^a-z0-9]+/);
  for (let i = 0; i < w.length; i++) { const x = WN[w[i]] || (/^\d{1,2}$/.test(w[i]) ? +w[i] : 0); if (x && x < 10 && /^(chambre|ch|piece)/.test(w[i + 1] || "")) f.bedrooms = x; }
  f.wolof = /dama|begg|bëgg|ñaari|naari|ci |nga |jerejef|ndax|waaw/.test(n);
  return f;
}
async function llmParse(text) {
  if (!AI_API_KEY) return null;
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", signal: AbortSignal.timeout(15000),
      headers: { "content-type": "application/json", "x-api-key": AI_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: process.env.AI_MODEL || "claude-sonnet-4-6", max_tokens: 400,
        system: "Tu es KAYMALOUER AI, assistant de location immobilière au Sénégal. Tu comprends le français et le wolof. Réponds UNIQUEMENT par un JSON : {\"category\":\"appartement|chambre|maison|magasin|bureau|local-commercial|null\",\"place\":\"ville ou quartier ou null\",\"max_price\":nombre ou null,\"bedrooms\":nombre ou null,\"reply\":\"réponse courte et chaleureuse dans la langue de l'utilisateur\"}. N'invente jamais d'annonce.",
        messages: [{ role: "user", content: text }] })
    });
    if (!r.ok) return null;
    const j = await r.json();
    return JSON.parse((j.content || []).map(c => c.text || "").join("").replace(/```json|```/g, "").trim());
  } catch { return null; }
}
app.post("/api/ai", aiLim, wrap(async (req, res) => {
  const { message } = z.object({ message: z.string().trim().min(2).max(500) }).parse(req.body);
  const rp = ruleParse(message), l = await llmParse(message);
  const num = x => (Number.isFinite(+x) && +x > 0 ? Math.round(+x) : undefined);
  const f = {
    category: CATS.has(l?.category) ? l.category : rp.category,
    place: (typeof l?.place === "string" && l.place.trim().slice(0, 60)) || rp.place,
    max: num(l?.max_price) || rp.max, bedrooms: num(l?.bedrooms) || rp.bedrooms
  };
  const items = await searchProps(f, 5);
  q("INSERT INTO events (type) VALUES ('search')").catch(() => {});
  const wo = rp.wolof;
  const reply = (typeof l?.reply === "string" && l.reply.slice(0, 400)) ||
    (items.length ? (wo ? `Jàmm ! Gis naa ${items.length} annonce.` : `J'ai trouvé ${items.length} annonce(s) pour vous.`) : (wo ? "Amul dara. Jéem yokk njëg li." : "Aucune annonce trouvée, essayez d'élargir votre budget ou la zone."));
  res.json({ filters: f, reply, items });
}));
const CATS = new Set(["appartement", "chambre", "maison", "magasin", "bureau", "local-commercial"]);

/* ---------- Administration ---------- */
const admin = [auth("admin")];
app.get("/api/admin/stats", ...admin, wrap(async (_r, res) => {
  const { rows: [s] } = await q(`SELECT
    (SELECT count(*) FROM users)::int users, (SELECT count(*) FROM properties)::int properties,
    (SELECT count(*) FROM properties WHERE status='active')::int active, (SELECT count(*) FROM properties WHERE status='pending')::int pending,
    (SELECT count(*) FROM users WHERE role IN ('owner','agency'))::int owners, (SELECT count(*) FROM events WHERE type='search')::int searches,
    (SELECT count(*) FROM events WHERE type='whatsapp_click')::int whatsapp_clicks, (SELECT count(*) FROM reports WHERE status='open')::int open_reports`);
  res.json(s);
}));
app.get("/api/admin/properties", ...admin, wrap(async (req, res) => {
  const st = z.enum(["pending", "active", "rejected", "blocked"]).optional().parse(req.query.status);
  const { rows } = await q(`${BASE} ${st ? "WHERE p.status=$1" : ""} ORDER BY p.created_at DESC LIMIT 200`, st ? [st] : []);
  res.json({ items: rows });
}));
app.post("/api/admin/properties/:id/status", ...admin, wrap(async (req, res) => {
  const d = z.object({ status: z.enum(["active", "rejected", "blocked"]), reason: z.string().max(300).optional() }).parse(req.body);
  await q("UPDATE properties SET status=$1, reject_reason=$2, updated_at=now() WHERE id=$3", [d.status, d.reason || null, uid.parse(req.params.id)]);
  res.json({ ok: true });
}));
app.get("/api/admin/users", ...admin, wrap(async (_r, res) =>
  res.json({ items: (await q("SELECT id,name,phone,email,role,blocked,verified,created_at FROM users ORDER BY created_at DESC LIMIT 300")).rows })));
app.post("/api/admin/users/:id/block", ...admin, wrap(async (req, res) => {
  const { blocked } = z.object({ blocked: z.boolean() }).parse(req.body);
  const r = await q("UPDATE users SET blocked=$1 WHERE id=$2 AND role<>'admin'", [blocked, uid.parse(req.params.id)]);
  if (!r.rowCount) return fail(res, 404, "Utilisateur introuvable ou protégé"); res.json({ ok: true });
}));
app.get("/api/admin/reports", ...admin, wrap(async (_r, res) =>
  res.json({ items: (await q("SELECT r.*, p.title FROM reports r JOIN properties p ON p.id=r.property_id ORDER BY (r.status='open') DESC, r.created_at DESC LIMIT 200")).rows })));
app.post("/api/admin/reports/:id/resolve", ...admin, wrap(async (req, res) => {
  await q("UPDATE reports SET status='resolved' WHERE id=$1", [z.coerce.number().int().parse(req.params.id)]); res.json({ ok: true });
}));
app.post("/api/admin/categories", ...admin, wrap(async (req, res) => {
  const d = z.object({ slug: z.string().regex(/^[a-z0-9-]{2,40}$/), label: z.string().trim().min(2).max(60) }).parse(req.body);
  await q("INSERT INTO categories (slug,label) VALUES ($1,$2)", [d.slug, d.label]); CATS.add(d.slug); res.status(201).json({ ok: true });
}));
app.delete("/api/admin/categories/:slug", ...admin, wrap(async (req, res) => {
  try { await q("DELETE FROM categories WHERE slug=$1", [req.params.slug]); CATS.delete(req.params.slug); res.json({ ok: true }); }
  catch (e) { if (e.code === "23503") return fail(res, 409, "Catégorie utilisée par des annonces"); throw e; }
}));

/* ---------- Erreurs ---------- */
app.use("/api", (_r, res) => fail(res, 404, "Route inconnue"));
app.use((e, _req, res, _next) => {
  if (e instanceof z.ZodError) return fail(res, 400, e.issues[0].path.join(".") + " : " + e.issues[0].message);
  if (e.name === "MulterError") return fail(res, 400, e.code === "LIMIT_FILE_SIZE" ? "Image trop lourde (3 Mo max)" : "Envoi de fichiers invalide");
  if (e.status) return fail(res, e.status, e.message);
  console.error(e); fail(res, 500, "Erreur serveur");
});
(async () => {
  try { (await q("SELECT slug FROM categories")).rows.forEach(r => CATS.add(r.slug)); } catch (e) { console.error("Base de données inaccessible :", e.message); }
  app.listen(process.env.PORT || 4000, () => console.log("KAYMALOUER LA API prête sur le port " + (process.env.PORT || 4000)));
})();
