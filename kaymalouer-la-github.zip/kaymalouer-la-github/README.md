# KAYMALOUER LA 🇸🇳

Application de location au Sénégal : appartements, chambres, maisons, magasins, bureaux.
WhatsApp officiel : +221 77 678 51 61

| Dossier | Contenu |
|---|---|
| `web/` | Application web (un seul fichier `index.html`, version téléphone et ordinateur) |
| `promo/` | Vidéo promo animée avec voix off |
| `server/` | API Node.js + PostgreSQL (voir `server/README.md`) |
| `android/` | Projet Capacitor pour générer l'APK / AAB (voir `android/README.md`) |
| `windows/` | Projet Electron pour le logiciel Windows (voir `windows/README.md`) |

Le logiciel Windows se compile automatiquement : onglet **Actions > Build Windows > Run workflow**, puis téléchargement de l'artefact.

Ne jamais publier de fichier `.env`, de clé IA ni de keystore Android.
